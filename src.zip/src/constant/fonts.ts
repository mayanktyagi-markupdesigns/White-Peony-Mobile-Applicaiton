const Fonts = {

  Ubuntu_Regular: 'Ubuntu-R',
  Ubuntu_Bold: 'Ubuntu-B',
  Ubuntu_Light: 'Ubuntu-L',
  Ubuntu_Medium: 'Ubuntu-M',
  Ubuntu_Italic: 'Ubuntu-RI',
  Ubuntu_Bold_Italic: 'Ubuntu-BI',
  Ubuntu_Light_Italic: 'Ubuntu-LI',
  Ubuntu_Medium_Italic: 'Ubuntu-MI',
  Ubuntu_Condensed_Regular: 'Ubuntu-C',

};
export default Fonts;
