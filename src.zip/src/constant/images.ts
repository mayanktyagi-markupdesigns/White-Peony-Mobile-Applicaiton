const Images = {
  // logo: require("../assets/png/pagelogo.png"),
  // intro1: require("../assets/png/Intro.png"),
  // intro2: require("../assets/png/trailers.png"),
  // back: require("../assets/png/back.png"),
  // forword: require("../assets/png/forword.png"),
  home: require("../assets/Png/hometab.png"),
  category: require("../assets/Png/shopping-bag.png"),
  event: require("../assets/Png/events.png"),
  article: require("../assets/Png/blogs.png"),
  account: require("../assets/Png/Accounts.png"),

  // rightArrow: require("../assets/png/next.png"),
  // order: require("../assets/png/order.png"),
  // info: require("../assets/png/info.png"),
  // phone: require("../assets/png/phone.png"),
  // chat: require("../assets/png/chat.png"),
  // more: require("../assets/png/more.png"),
  // edit: require("../assets/png/editing.png"),
  // back2: require("../assets/png/forword2.png"),
  // product: require('../assets/png/Product.png'),
  //  delete: require("../assets/png/delete.png"),
  // uncheack: require('../assets/png/cheack.png'),
  // cheack: require('../assets/png/check-box.png'),
  // LoginPage: require('../assets/png/logInPage.png'),
  // owner: require('../assets/png/Owner.png'),
  // ic_upload_image: require('../assets/png/ic_upload_image.png'),
  // emptycart: require('../assets/png/empty-cart.png'),
  // square_checkbox_checked: require('../assets/png/ic_square_checked.png'),
  // square_checkbox_unchecked: require('../assets/png/ic_square_unchecked.png'),

  // defaultProfile: "https://icons.veryicon.com/png/o/education-technology/alibaba-big-data-oneui/user-profile.png"


};
export default Images;
