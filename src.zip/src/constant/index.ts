import Colors from "./colors";
import Fonts from "./fonts";
import Typography from "./fontSize";
import Images from "./images";

export { Fonts, Colors, Typography,Images };
