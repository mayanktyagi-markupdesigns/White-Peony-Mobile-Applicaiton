import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const CategoryByProduct = () => {
  return (
    <View>
      <Text>CategoryByProduct</Text>
    </View>
  )
}

export default CategoryByProduct

const styles = StyleSheet.create({})